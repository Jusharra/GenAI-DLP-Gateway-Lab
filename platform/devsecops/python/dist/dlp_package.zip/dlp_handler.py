import json
import os
import uuid
from datetime import datetime

import boto3

s3 = boto3.client("s3")
lambda_client = boto3.client("lambda")

EVIDENCE_BUCKET = os.environ["EVIDENCE_BUCKET_NAME"]
RAG_LAMBDA_NAME = os.environ["RAG_LAMBDA_NAME"]


def detect_pii(text: str):
    """
    Placeholder PII detection.
    In a real deployment you would use Microsoft Presidio or another DLP engine.
    For the lab, this is enough to show the control logic and evidence pattern.
    """
    findings = []

    lowered = (text or "").lower()
    if "ssn" in lowered or "social security" in lowered:
        findings.append({"type": "SSN"})

    if "credit card" in lowered:
        findings.append({"type": "CREDIT_CARD"})

    if "patient" in lowered or "phi" in lowered:
        findings.append({"type": "PHI"})

    return findings


def evaluate_policy(role: str, pii_findings: list) -> str:
    """
    Simple policy model that mirrors what you'd encode in Rego:
      - If no PII found -> allow
      - If PII found and role is 'dlp-admin' or 'security-engineer' -> mask
      - If PII found and role is anything else -> block
    """
    if not pii_findings:
        return "allow"

    privileged_roles = {"dlp-admin", "security-engineer"}

    if role in privileged_roles:
        return "mask"

    return "block"


def log_decision(stage: str, payload: dict, pii_findings: list, decision: str) -> str:
    """
    Writes a structured DLP decision record into the evidence S3 bucket.
    The record is intentionally generic so it can be reused across workloads.
    """
    decision_id = str(uuid.uuid4())

    record = {
        "decision_id": decision_id,
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "stage": stage,  # "request" or "response"
        "decision": decision,
        "pii_findings": pii_findings,
        "role": payload.get("role") or payload.get("user_role"),
        # NEVER log full prompt in production; this is a truncated preview for the lab.
        "prompt_preview": (payload.get("prompt") or "")[:200],
    }

    key = f"dlp-decisions/{stage}/{datetime.utcnow().date()}/{decision_id}.json"

    s3.put_object(
        Bucket=EVIDENCE_BUCKET,
        Key=key,
        Body=json.dumps(record).encode("utf-8"),
    )

    return decision_id


def build_error(status_code: int, message: str, decision_id: str | None = None):
    body = {"error": message}
    if decision_id:
        body["decision_id"] = decision_id

    return {
        "statusCode": status_code,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(body),
    }


def lambda_handler(event, context):
    """
    Entry point for API Gateway → DLP Filter Lambda.

    Expects body like:
      {
        "user_id": "123",
        "role": "analyst",
        "prompt": "User's prompt here"
      }
    """
    try:
        raw_body = event.get("body") or "{}"
        body = json.loads(raw_body)
    except (TypeError, ValueError):
        # malformed input
        return build_error(400, "Invalid JSON payload")

    user_role = body.get("role", "unknown")
    prompt = body.get("prompt")

    if not prompt:
        return build_error(400, "Missing 'prompt' in request body")

    pii_findings = detect_pii(prompt)
    decision = evaluate_policy(user_role, pii_findings)
    decision_id = log_decision("request", {"prompt": prompt, "role": user_role}, pii_findings, decision)

    if decision == "block":
        # Do NOT forward to RAG if blocked
        return build_error(400, "Prompt blocked by DLP policy.", decision_id=decision_id)

    # For "mask" you might transform the prompt; for this lab we just pass through.
    forward_body = {
        "prompt": prompt,
        "user_role": user_role,
        "original_decision_id": decision_id,
    }

    try:
        rag_response = lambda_client.invoke(
            FunctionName=RAG_LAMBDA_NAME,
            InvocationType="RequestResponse",
            Payload=json.dumps(forward_body).encode("utf-8"),
        )
    except Exception as e:
        # Operational failure
        return build_error(500, f"Error invoking RAG orchestrator: {e}")

    try:
        rag_payload = json.loads(rag_response["Payload"].read())
    except (TypeError, ValueError):
        return build_error(500, "Invalid response from RAG orchestrator")

    return {
        "statusCode": 200,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(rag_payload),
    }
