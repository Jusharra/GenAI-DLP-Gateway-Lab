import json
import os
import uuid
from datetime import datetime

import boto3
import pinecone

s3 = boto3.client("s3")

# Bedrock client (you can stub if Bedrock is not available in your account/region)
bedrock = boto3.client("bedrock-runtime", region_name=os.environ.get("AWS_REGION", "us-east-1"))

EVIDENCE_BUCKET = os.environ["EVIDENCE_BUCKET_NAME"]
PINECONE_API_KEY = os.environ["PINECONE_API_KEY"]
PINECONE_ENV = os.environ["PINECONE_ENVIRONMENT"]
PINECONE_INDEX_NAME = os.environ["PINECONE_INDEX_NAME"]
MODEL_ID = os.environ.get("MODEL_ID", "stub-model")

pinecone.init(api_key=PINECONE_API_KEY, environment=PINECONE_ENV)
index = pinecone.Index(PINECONE_INDEX_NAME)


def detect_pii(text: str):
    """
    Same simplified PII detector used in the DLP Lambda.
    In production this should be shared code / proper DLP engine.
    """
    findings = []
    lowered = (text or "").lower()

    if "ssn" in lowered or "social security" in lowered:
        findings.append({"type": "SSN"})

    if "credit card" in lowered:
        findings.append({"type": "CREDIT_CARD"})

    if "patient" in lowered or "phi" in lowered:
        findings.append({"type": "PHI"})

    return findings


def evaluate_policy(role: str, pii_findings: list) -> str:
    if not pii_findings:
        return "allow"

    privileged_roles = {"dlp-admin", "security-engineer"}

    if role in privileged_roles:
        return "mask"

    return "block"


def log_decision(stage: str, answer: str, pii_findings: list, role: str) -> str:
    decision_id = str(uuid.uuid4())

    record = {
        "decision_id": decision_id,
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "stage": stage,
        "decision": "block" if pii_findings else "allow",  # updated later if masked
        "pii_findings": pii_findings,
        "role": role,
        "answer_preview": (answer or "")[:200],
    }

    key = f"dlp-decisions/{stage}/{datetime.utcnow().date()}/{decision_id}.json"

    s3.put_object(
        Bucket=EVIDENCE_BUCKET,
        Key=key,
        Body=json.dumps(record).encode("utf-8"),
    )

    return decision_id


def retrieve_context(prompt: str) -> str:
    """
    RAG context retrieval.
    For a lab, you can either:
      - Use a static vector (as here) and pre-loaded index metadata, or
      - Use a real embedding model and vector.
    """
    # NOTE: Replace this with real embeddings in a more advanced version.
    dummy_vector = [0.0] * 16

    try:
        results = index.query(vector=dummy_vector, top_k=3, include_metadata=True)
    except Exception:
        # Fail gracefully in lab mode
        return ""

    matches = results.get("matches") or []
    snippets = []

    for m in matches:
        metadata = m.get("metadata") or {}
        text = metadata.get("text")
        if text:
            snippets.append(text)

    return "\n---\n".join(snippets)


def call_llm(prompt: str, context: str) -> str:
    """
    Calls Bedrock or returns a stubbed answer if MODEL_ID is "stub-model".
    """
    if MODEL_ID == "stub-model":
        # Stubbed answer for accounts without Bedrock enabled
        return f"[STUBBED ANSWER]\n\nContext:\n{context}\n\nPrompt:\n{prompt}"

    # Example Bedrock-style payload; adjust to your chosen model/schema.
    body = {
        "prompt": f"Context:\n{context}\n\nUser prompt:\n{prompt}",
        "temperature": 0.2,
        "max_tokens": 512,
    }

    response = bedrock.invoke_model(
        modelId=MODEL_ID,
        body=json.dumps(body),
    )

    raw = response["body"].read()
    data = json.loads(raw)

    # This will depend on the selected model; adjust accordingly.
    # For a lab, returning a generic "output_text" is fine as a pattern.
    return data.get("output_text") or json.dumps(data)


def lambda_handler(event, context):
    """
    Expects payload from DLP Lambda:

      {
        "prompt": "...",
        "user_role": "...",
        "original_decision_id": "..."
      }
    """
    prompt = event.get("prompt")
    role = event.get("user_role", "unknown")

    if not prompt:
        return {"error": "Missing 'prompt' in event payload"}

    context_text = retrieve_context(prompt)
    answer = call_llm(prompt, context_text)

    pii_findings = detect_pii(answer)
    decision = evaluate_policy(role, pii_findings)

    decision_id = log_decision("response", answer, pii_findings, role)

    if decision == "block":
        safe_answer = "Response blocked by DLP policy."
    elif decision == "mask":
        # Very naive masking for demo purposes.
        safe_answer = "[PII REDACTED] " + answer
    else:
        safe_answer = answer

    return {
        "answer": safe_answer,
        "decision_id": decision_id,
        "role": role,
    }
